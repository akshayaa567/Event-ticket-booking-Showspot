package com.showspot.contactapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactapiApplication {
    public static void main(String[] args) {
        SpringApplication.run(ContactapiApplication.class, args);
    }
}
