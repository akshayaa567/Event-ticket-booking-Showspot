package com.showspot.contactapi.service;

import com.showspot.contactapi.model.ContactMessage;
import java.util.List;

public interface ContactService {
    ContactMessage saveMessage(ContactMessage contact);
    List<ContactMessage> getAllMessages(); // ✅ just the method signature
}
